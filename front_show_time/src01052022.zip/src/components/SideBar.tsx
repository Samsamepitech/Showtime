import React from "react"; 
import {CardImg, Nav} from "react-bootstrap";
import axiosRequest from "../api/Requests";
import { apiUrl } from "../api/axios-ask";
import { useRef, useState, useEffect } from "react";
import { BrowserRouter as Router, Route, Link} from "react-router-dom";
import '../style/Sidebar.css'


export const Sidebar = () => {

    const [concerts, setConcerts] = useState("");
  
    

    return (
    <>
            <Nav className="col-md-12 d-none d-md-block sidebar"
            activeKey="/home"
            onSelect={selectedKey => alert(`selected ${selectedKey}`)} as="ul"
            >
                <div className="sidebar-sticky"></div>
            <Nav.Item as="li">
                <Nav.Link href="/home"><h4>Voir tout</h4></Nav.Link>
            </Nav.Item>
            <CardImg variant="top" src="../images/play_list_foule.jpg" className="col-ml-12"></CardImg>
            <Nav.Item as="li">
                <Nav.Link eventKey="Festivals" className="nav-li"> <h4>&#x000BB; Festivals </h4></Nav.Link>
            </Nav.Item>
            <Nav.Item as="li">
                <Nav.Link eventKey="Pop Rock" className="nav-li"><h4> &#x000BB; Pop &amp; Rock</h4></Nav.Link>
            </Nav.Item>
            <Nav.Item as="li">
                <Nav.Link eventKey="Jazz Blues Funk" className="nav-li"> <h4>&#x000BB; Jazz / Blues / Funk</h4></Nav.Link>
            </Nav.Item>
            <Nav.Item as="li">
                <Nav.Link eventKey="Folklore Gospel" className="nav-li"><h4>&#x000BB; Folklore &amp; Gospel</h4> </Nav.Link>
            </Nav.Item>
            <Nav.Item as="li">
                <Nav.Link eventKey="Open Air" className="nav-li"><h4> &#x000BB; Open Air</h4></Nav.Link>
            </Nav.Item>
            <Nav.Item as="li">
                <Nav.Link eventKey="Heavy Metal" className="nav-li"><h4>&#x000BB; Heavy Metal</h4> </Nav.Link>
            </Nav.Item>
            <Nav.Item as="li">
                <Nav.Link eventKey="Hip-hop Rap" className="nav-li"><h4> &#x000BB; Hip-hop &amp; Rap</h4></Nav.Link>
            </Nav.Item>
            <Nav.Item as="li">
                <Nav.Link eventKey="Latino" className="nav-li"><h4>&#x000BB; Latino </h4> </Nav.Link>
            </Nav.Item>
            <Nav.Item as="li">
                <Nav.Link eventKey="Country Folk" className="nav-li"><h4> &#x000BB; Country/ Folk</h4> </Nav.Link>
            </Nav.Item>
            <Nav.Item as="li">
                <Nav.Link eventKey="House Electro" className="nav-li"><h4>&#x000BB; House/ Electro</h4>  </Nav.Link>
            </Nav.Item>
            <Nav.Item as="li">
                <Nav.Link eventKey="Reggae Dancehall" className="nav-li"> <h4>&#x000BB; Reggae/Dancehall </h4></Nav.Link>
            </Nav.Item>
            <Nav.Item as="li">
                <Nav.Link eventKey="Alternative" className="nav-li"> <h4>&#x000BB; Alternative </h4></Nav.Link>
            </Nav.Item>
            <Nav.Item>
                <Nav.Link eventKey="Drum Bass" className="nav-li"><h4>&#x000BB; Drum &amp; Bass </h4></Nav.Link>
            </Nav.Item>
            <Nav.Item as="li">
                <Nav.Link eventKey="link-2"> </Nav.Link>
            </Nav.Item>
            <Nav.Item as="li">
                <Nav.Link eventKey="disabled" disabled>
                Next Events
                </Nav.Link>
            </Nav.Item>
            </Nav>
        </>  
        );
    }
  

  export default Sidebar