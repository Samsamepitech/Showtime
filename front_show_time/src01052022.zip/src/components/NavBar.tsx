import React from 'react';
import axios from 'axios';
import {useRef, useState, useEffect } from 'react';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { BrowserRouter as Router, Route,Link} from "react-router-dom";
import {Button, Navbar, Col, Container, Form, Row, Nav, NavDropdown, InputGroup} from "react-bootstrap";
import '../style/Home.css';
import SearchBar from './SearchBar';



export const NavBar = () => {

    return (
        <>
        <Navbar bg="light" expand="lg">
        <Navbar.Brand href="/"><img src="../images/ticketcorner.png"/> </Navbar.Brand>
          <SearchBar></SearchBar>
        
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">
              <Nav className="me-auto">
                <Nav.Link href="/login"><h5>Login</h5></Nav.Link>
                <Nav.Link href="/register"><h5>Register</h5></Nav.Link>
              </Nav>
            </Navbar.Collapse>
          </Navbar>
        </>
    )
}
export default NavBar;