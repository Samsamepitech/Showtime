import React, { useState } from "react"; 
import {Carousel} from 'react-bootstrap';
import { BrowserRouter as Router, Route, Link} from "react-router-dom";


export const CarouselMod = () => {
   
    /** stokcage image renvoie vers comp
     * const image = require("./assets/cat.jpg").default;
export default class testComponent extends Component {
  render() {
    return (
      <div>
        <img src={image} />
      </div>
    );
  }
}
     */

    return (

<Carousel>
  <Carousel.Item className="slide" interval={2000}>
  <Link to={("/concert")}><img className="d-block w-60" src="../images/958-orelsan.jpg" alt="First slide" /> </Link>
    <Carousel.Caption>
      <h3>First slide label</h3>
      <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
    </Carousel.Caption>
  </Carousel.Item>
  <Carousel.Item className="slide" interval={2000}>
   <Link to={("/concert")}><img className="d-block w-60" src="../images/car_ic_musica-ete_dizier2022.jpg" alt="Second slide"/></Link>  
    <Carousel.Caption>
      <h3>Second slide label</h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
    </Carousel.Caption>
  </Carousel.Item>
  <Carousel.Item className="slide" interval={2000}>
  <Link to={("/concert")}> <img
      className="d-block w-60"
      src="../images/car_ic_scorpions_2022.jpg"
      alt="Third slide"
    /> </Link>
    <Carousel.Caption>
      <h3>Third slide label</h3>
      <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
    </Carousel.Caption>
  </Carousel.Item>
  <Carousel.Item className="slide" interval={2000}>
  <Link to={("/concert")}><img
      className="d-block w-60"
      src="../images/car_ic_tiken_jah_fakoli_avril_2022_new.jpg"
      alt="Third slide"
    /> </Link>
    <Carousel.Caption>
      <h3>Third slide label</h3>
      <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
    </Carousel.Caption>
  </Carousel.Item>
  <Carousel.Item className="slide" interval={2000}>
  <Link to={("/concert")}><img className="d-block w-60" src="../images/car_ic_zucchero_tour_2022.jpg"
      alt="Third slide"
    /> </Link>
    <Carousel.Caption>
      <h3>Third slide label</h3>
      <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
    </Carousel.Caption>
  </Carousel.Item>
  <Carousel.Item className="slide" interval={2000}>
  <Link to={("/concert")}> <img className="d-block w-60" src="../images/958-the-rabeats.jpg" alt="Third slide" /> </Link>
    <Carousel.Caption>
      <h3>Third slide label</h3>
      <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
    </Carousel.Caption>
  </Carousel.Item>
</Carousel>
        );
    }
  
    export default CarouselMod;